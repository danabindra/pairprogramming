# 🧠 Scrabble Showdown – Pair Programming Blog

**Pair Members**:  
**Dates**:  

---

## Day 1 – Getting Started
Our plan, who did what, first thoughts on Git + Python

## Day 2 – Input and Validation
What we coded today. Problems? Wins?

## Day 3 – Scoring
How our scoring works. What role did I take today?

## Day 4 – Loop + Replay
New feature or bug fix? What did we learn from it?

## Day 5 – Wrap-Up
What we’re proud of. Screenshot of our game.

---

## 🧠 Final Thoughts
Three things we learned this week:
- 
- 
- 
